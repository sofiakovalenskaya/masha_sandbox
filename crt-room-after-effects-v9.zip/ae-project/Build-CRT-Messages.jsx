#target aftereffects

(function () {
    var scriptFolder = File($.fileName).parent;
    var assets = Folder(scriptFolder.fsName + "/assets");
    var timeline = File(scriptFolder.fsName + "/timeline.json");
    var fps = 30;
    var duration = 10;
    var plateW = 1920;
    var plateH = 1080;
    var spriteW = 1120;
    var spriteH = 640;

    function readTimeline(file) {
        file.encoding = "UTF-8";
        if (!file.open("r")) {
            throw new Error("timeline.json is missing. Unzip the full project first.");
        }
        var data = file.read();
        file.close();
        // ExtendScript versions without JSON.parse still accept the supplied JSON literal.
        return eval("(" + data + ")");
    }

    function importAsset(name, folder) {
        var file = File(assets.fsName + "/" + name);
        if (!file.exists) {
            throw new Error("Missing asset: " + name);
        }
        var footage = app.project.importFile(new ImportOptions(file));
        footage.parentFolder = folder;
        return footage;
    }

    function layerProperty(layer, name) {
        return layer.property("ADBE Transform Group").property(name);
    }

    function bake(layer, propertyName, samples, getValue) {
        var prop = layerProperty(layer, propertyName);
        var times = [];
        var values = [];
        for (var i = 0; i < samples.length; i++) {
            times.push(samples[i][0] / fps);
            values.push(getValue(samples[i]));
        }
        prop.setValuesAtTimes(times, values);
        for (var j = 1; j <= prop.numKeys; j++) {
            prop.setInterpolationTypeAtKey(j, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
        }
    }

    function animateMotion(layer, track) {
        layer.startTime = 0;
        layer.inPoint = track.start / fps;
        layer.outPoint = duration;
        layer.motionBlur = true;
        bake(layer, "ADBE Position", track.samples, function (key) { return [key[1], key[2]]; });
        bake(layer, "ADBE Scale", track.samples, function (key) { return [50 * key[3], 50 * key[3]]; });
        bake(layer, "ADBE Rotate Z", track.samples, function (key) { return key[4]; });
    }

    function makeBubble(track, n, media, precomps) {
        var comp = app.project.items.addComp(track.text, spriteW, spriteH, 1, duration, fps);
        comp.parentFolder = precomps;

        comp.layers.add(importAsset("message-" + n + "-lit.png", media)).name = "Light bubble";
        var dim = comp.layers.add(importAsset("message-" + n + "-dim.png", media));
        dim.name = "Dim after the next message";
        bake(dim, "ADBE Opacity", track.samples, function (key) { return 100 * key[7]; });

        var text = comp.layers.addText(track.text);
        var textProp = text.property("ADBE Text Properties").property("ADBE Text Document");
        var doc = textProp.value;
        doc.fontSize = 62;
        doc.fillColor = [35 / 255, 41 / 255, 45 / 255];
        doc.applyFill = true;
        doc.applyStroke = false;
        doc.justification = ParagraphJustification.CENTER_JUSTIFY;
        try { doc.font = "Inter-Medium"; } catch (fontError) { doc.font = "ArialMT"; }
        textProp.setValue(doc);
        layerProperty(text, "ADBE Position").setValue([spriteW / 2, spriteH / 2 + 18]);
        bake(text, "ADBE Opacity", track.samples, function (key) { return 100 - 13 * key[7]; });
        return comp;
    }

    function build(tracks) {
        var folder = app.project.items.addFolder("CRT Messages");
        var media = app.project.items.addFolder("Media");
        var precomps = app.project.items.addFolder("Message Precomps");
        media.parentFolder = folder;
        precomps.parentFolder = folder;
        var comp = app.project.items.addComp("CRT Room - Telegram Messages", plateW, plateH, 1, duration, fps);
        comp.parentFolder = folder;
        comp.motionBlur = true;
        comp.shutterAngle = 180;
        comp.shutterPhase = -90;

        var room = comp.layers.add(importAsset("room.mp4", media));
        room.name = "Original room video";
        room.locked = true;
        var ping = importAsset("telegram-incoming.mp3", media);
        var i;
        for (i = 0; i < tracks.length; i++) {
            var halo = comp.layers.add(importAsset("message-" + (i+1) + "-halo.png", media));
            halo.name = "White contour glow and wall spill " + (i+1);
            animateMotion(halo, tracks[i]);
            bake(halo, "ADBE Opacity", tracks[i].samples, function (key) { return 100 * key[6]; });
        }
        for (i = 0; i < tracks.length; i++) {
            var track = tracks[i];
            var bubble = comp.layers.add(makeBubble(track, i+1, media, precomps));
            animateMotion(bubble, track);
            bake(bubble, "ADBE Opacity", track.samples, function (key) { return 100 * key[5]; });
            var sound = comp.layers.add(ping);
            sound.name = "Telegram incoming " + (i+1);
            sound.startTime = track.start / fps;
            sound.property("ADBE Audio Group").property("ADBE Audio Levels").setValue([5, 5]);

            var marker = new MarkerValue(track.text);
            comp.markerProperty.setValueAtTime(track.start / fps, marker);
        }
        comp.openInViewer();
        return comp;
    }

    try {
        var tracks = readTimeline(timeline);
        var projectHasContent = app.project && app.project.numItems > 0;
        if (!app.project) {
            app.newProject();
        }
        app.beginUndoGroup("Build CRT Room Messages");
        try {
            build(tracks);
        } finally {
            app.endUndoGroup();
        }
        if (!projectHasContent) {
            var out = File(scriptFolder.fsName + "/CRT Room - Telegram Messages v9.aep");
            if (out.exists) {
                out = File.saveDialog("Save the new CRT Room project as an AEP");
                if (!out) return;
            }
            app.project.save(out);
        }
    } catch (err) {
        alert("CRT Room project: " + err.toString());
    }
}());
